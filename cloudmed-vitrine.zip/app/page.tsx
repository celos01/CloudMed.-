import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function CloudMedVitrine() {
  return (
    <div className="min-h-screen bg-green-100 flex flex-col items-center justify-center p-6">
      <header className="text-center mb-10">
        <img src="/logo.png" alt="CloudMed Logo" className="h-20 mx-auto mb-4" />
        <h1 className="text-4xl font-bold text-green-800">CloudMed</h1>
        <p className="text-green-700 mt-2 max-w-xl mx-auto">
          Armazene e acesse seus exames e dados médicos de forma digital e segura. Tenha tudo na palma da mão.
        </p>
      </header>

      <section className="grid md:grid-cols-2 gap-6 max-w-4xl w-full mb-10">
        <Card className="shadow-xl">
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold text-green-800 mb-4">Benefícios</h2>
            <ul className="list-disc pl-6 text-green-700 space-y-2">
              <li>Acesso rápido e fácil a exames</li>
              <li>Parceria com hospitais e consultórios</li>
              <li>Fim dos papéis e impressões</li>
              <li>Segurança e praticidade</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="shadow-xl">
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold text-green-800 mb-4">Login / Cadastro</h2>
            <form className="space-y-4">
              <Input placeholder="Email" className="bg-white" />
              <Input placeholder="Senha" type="password" className="bg-white" />
              <Button className="bg-green-600 hover:bg-green-700 text-white w-full">Entrar</Button>
            </form>
            <p className="text-sm text-green-700 mt-4 text-center">
              Ainda não tem conta? <a href="#" className="underline">Cadastre-se</a>
            </p>
          </CardContent>
        </Card>
      </section>

      <section className="grid md:grid-cols-2 gap-6 max-w-4xl w-full mb-10">
        <Card className="shadow-xl">
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold text-green-800 mb-4">Enviar Exames</h2>
            <Label className="text-green-700 mb-2 block">Selecione o arquivo</Label>
            <Input type="file" className="bg-white" />
            <p className="text-sm text-green-600 mt-2">Formatos aceitos: PDF, JPG, PNG</p>
            <Button className="mt-4 bg-green-600 hover:bg-green-700 text-white w-full">Anexar</Button>
          </CardContent>
        </Card>

        <Card className="shadow-xl">
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold text-green-800 mb-4">Meus Arquivos</h2>
            <ul className="space-y-2 text-green-700">
              <li className="flex justify-between bg-green-50 p-2 rounded-md">
                <span>exame-sangue.pdf</span>
                <Button size="sm" className="bg-green-500 text-white">Visualizar</Button>
              </li>
              <li className="flex justify-between bg-green-50 p-2 rounded-md">
                <span>raio-x-peito.png</span>
                <Button size="sm" className="bg-green-500 text-white">Visualizar</Button>
              </li>
            </ul>
          </CardContent>
        </Card>
      </section>

      <section className="max-w-4xl w-full mb-10">
        <h2 className="text-3xl font-bold text-green-800 text-center mb-6">Planos</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="shadow-xl border-2 border-green-400">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold text-green-800 mb-2">Freemium</h3>
              <p className="text-green-700 mb-4">Ideal para uso pessoal</p>
              <ul className="list-disc pl-6 text-green-700 space-y-2 mb-4">
                <li>Upload de até 10 arquivos</li>
                <li>Acesso web e mobile</li>
                <li>Gratuito para sempre</li>
              </ul>
              <Button className="bg-green-600 hover:bg-green-700 text-white w-full">Usar Plano Grátis</Button>
            </CardContent>
          </Card>

          <Card className="shadow-xl">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold text-green-800 mb-2">Profissional</h3>
              <p className="text-green-700 mb-4">Para clínicas e consultórios</p>
              <ul className="list-disc pl-6 text-green-700 space-y-2 mb-4">
                <li>Armazenamento ilimitado</li>
                <li>Relatórios automáticos</li>
                <li>Suporte premium</li>
              </ul>
              <Button className="bg-green-600 hover:bg-green-700 text-white w-full">Assinar</Button>
            </CardContent>
          </Card>
        </div>
      </section>

      <footer className="mt-12 text-green-600 text-sm text-center">
        &copy; 2025 CloudMed. Todos os direitos reservados.
      </footer>
    </div>
  );
}