import React from "react";

export function Label({ children, className }: any) {
  return <label className={className}>{children}</label>;
}