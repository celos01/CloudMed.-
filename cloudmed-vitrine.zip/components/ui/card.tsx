import React from "react";

export function Card({ children, className }: any) {
  return <div className={`rounded-2xl bg-white ${className}`}>{children}</div>;
}

export function CardContent({ children, className }: any) {
  return <div className={className}>{children}</div>;
}