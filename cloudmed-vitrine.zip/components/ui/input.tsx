import React from "react";

export function Input(props: any) {
  return (
    <input
      {...props}
      className={`border border-green-300 rounded-xl p-2 w-full ${props.className}`}
    />
  );
}